from model.BDeu_score import reward_BDeu
from model.BIC_score import reward_BIC
import pandas as pd
import numpy as np
import torch

datadf = pd.read_csv("./dataset/Asia/data.csv")
true_g = np.load('./dataset/Asia/True_DAG.npy')
np.save('./dataset/Asia/data.npy', datadf.to_numpy())
datanp = np.load("./dataset/Asia/data.npy")

g_gran = np.load('./paper_output/Asia/causal_DAG.npy')
print(g_gran)
g_daggnn = np.loadtxt("./paper_output/Asia/predG")
g_daggnn[np.abs(g_daggnn) < 0.1] = 0
g_daggnn = (g_daggnn !=0)
print(g_daggnn)
reward_bdeu = reward_BDeu(torch.tensor(datanp), len(datadf.columns))
reward_bic = reward_BIC(torch.tensor(datanp), len(datadf.columns))

scorebdeu = reward_bdeu.compute_score(torch.tensor(g_gran.T))
scorebic = reward_bic.compute_score(torch.tensor(g_gran.T))

print("BDeu:", scorebdeu.sum())
print("BIC:", scorebic.sum())
